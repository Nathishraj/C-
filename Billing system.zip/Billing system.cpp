#include <iostream>
using namespace std;
int purchase=0;
void ask();
void display();

   struct customer{
        string items;
        int quantity;
        int amount;
        }c[45];

int snacks(){
    int op;
   cout<<"1.Biscuits\n2.Chocolates\n3.Chips\n";
   cin>>op;
    switch(op)
    {
    case 1:
        {
        int op1;
        cout<<"\t\t\tBISCUITS:\nChoose it\n1.Dark Fantasy-30\n2.Parle G-5\n3.JimJam-10\n";
        cin>>op1;
        switch(op1)
        {
        case 1:
            {
        c[1].items="Dark Fantasy";
            int n1;
            int df=30;
            cout<<"Enter the count:\n";
            cin>>n1;
            c[1].quantity=n1;
            n1=n1*df;
            c[1].amount=n1;
            purchase+=n1;
            ask();
            break;
            }
        case 2:
            {
         c[2].items="Parle G";
            int n2;
            int pg=5;
            cout<<"Enter the count:\n";
            cin>>n2;
            c[2].quantity=n2;
            n2=n2*pg;
            c[2].amount=n2;
            purchase+=n2;
            ask();
            break;
            }
        case 3:
            {
          c[3].items="JimJam      ";
            int n3;
            int jj=10;
            cout<<"Enter the count:\n";
            cin>>n3;
            c[3].quantity=n3;
            n3=n3*jj;
            c[3].amount=n3;
            purchase+=n3;
            ask();
            break;
            }
        }
        break;
        }
        case 2:
            {
        int op2;
        cout<<"\t\t\tCHOCOLATES:\nChoose it\n1.Snickers-10\n2.KitKat-10\n3.DiaryMilk-40\n";
        cin>>op2;
        switch(op2)
        {
        case 1:
            {
          c[4].items="Snickers    ";
            int no1;
            int s=10;
            cout<<"Enter the count:\n";
            cin>>no1;
            c[4].quantity=no1;
            no1=no1*s;
            c[4].amount=no1;
            purchase+=no1;
            ask();
            break;
            }
        case 2:
            {
          c[5].items="KitKat      ";
            int no2;
            int kk=10;
            cout<<"Enter the count:\n";
            cin>>no2;
            c[5].quantity=no2;
            no2=no2*kk;
            c[5].amount=no2;
            purchase+=no2;
            ask();
            break;
            }
        case 3:
            {
          c[6].items="DairyMilk   ";
            int no3;
            int dm=40;
            cout<<"Enter the count:\n";
            cin>>no3;
            c[6].quantity=no3;
            no3=no3*dm;
            c[6].amount=no3;
            purchase+=no3;
            ask();
            break;
            }
        }
      break;
     }
        case 3:
            {
        int op3;
        cout<<"\t\t\tCHIPS:\nChoose it\n1.KuruKure-10\n2.Bingo-10\n3.Lays-30\n";
        cin>>op3;
        switch(op3)
        {
        case 1:
            {
          c[7].items="KuruKure    ";
            int nof1;
            int k=10;
            cout<<"Enter the count:\n";
            cin>>nof1;
            c[7].quantity=nof1;
            nof1=nof1*k;
            c[7].amount=nof1;
            purchase+=nof1;
            ask();
            break;
            }
        case 2:
            {
          c[8].items="Bingo       ";
            int nof2;
            int b=10;
            cout<<"Enter the count:\n";
            cin>>nof2;
            c[8].quantity=nof2;
            nof2=nof2*b;
            c[8].amount=nof2;
            purchase+=nof2;
            ask();
            break;
            }
        case 3:
            {
          c[9].items="Lays        ";
            int nof3;
            int l=30;
            cout<<"Enter the count:\n";
            cin>>nof3;
            c[9].quantity=nof3;
            nof3=nof3*l;
            c[9].amount=nof3;
            purchase+=nof3;
            ask();
            break;
            }
        }
      break;
     }
  }
}

int stationery(){
    int op;
   cout<<"1.NoteBooks\n2.Colors\n3.Others\n";
   cin>>op;
    switch(op)
    {
    case 1:
        {
        int op1;
        cout<<"\t\t\tNOTEBOOKS:(120 pages)\nChoose it\n1.Ruled Note-30\n2.Unruled Note-25\n3.Record Note-80\n";
        cin>>op1;
        switch(op1)
        {
        case 1:
            {
          c[10].items="Ruled Note  ";
            int n1;
            int run=30;
            cout<<"Enter the count:\n";
            cin>>n1;
            c[10].quantity=n1;
            n1=n1*run;
            c[10].amount=n1;
            purchase+=n1;
            ask();
            break;
            }
        case 2:
            {
          c[11].items="Unruled Note";
            int n2;
            int unr=25;
            cout<<"Enter the count:\n";
            cin>>n2;
            c[11].quantity=n2;
            n2=n2*unr;
            c[11].amount=n2;
            purchase+=n2;
            ask();
            break;
            }
        case 3:
            {
          c[12].items="Record Note ";
            int n3;
            int ren=80;
            cout<<"Enter the count:\n";
            cin>>n3;
            c[12].quantity=n3;
            n3=n3*ren;
            c[12].amount=n3;
            purchase+=n3;
            ask();
            break;
            }
        }
        break;
        }
        case 2:
            {
        int op2;
        cout<<"\t\t\tCOLORS(packs):\nChoose it\n1.Crayons-20\n2.Sketches-40\n3.Color Pencil-25\n";
        cin>>op2;
        switch(op2)
        {
        case 1:
            {
          c[13].items="Crayons     ";
            int no1;
            int cr=20;
            cout<<"Enter the count:\n";
            cin>>no1;
            c[13].quantity=no1;
            no1=no1*cr;
            c[13].amount=no1;
            purchase+=no1;
            ask();
            break;
            }
        case 2:
            {
          c[14].items="Sketches    ";
            int no2;
            int sk=40;
            cout<<"Enter the count:\n";
            cin>>no2;
            c[14].quantity=no2;
            no2=no2*sk;
            c[14].amount=no2;
            purchase+=no2;
            ask();
            break;
            }
        case 3:
            {
          c[15].items="Color Pencil";
            int no3;
            int cp=25;
            cout<<"Enter the count:\n";
            cin>>no3;
            c[15].quantity=no3;
            no3=no3*cp;
            c[15].amount=no3;
            purchase+=no3;
            ask();
            break;
            }
        }
      break;
     }
        case 3:
            {
        int op3;
        cout<<"\t\t\tOTHERS:\nChoose it\n1.Gum-10\n2.Stabler-30\n3.Tape-20\n";
        cin>>op3;
        switch(op3)
        {
        case 1:
            {
          c[16].items="Gum         ";
            int nof1;
            int gu=10;
            cout<<"Enter the count:\n";
            cin>>nof1;
            c[16].quantity=nof1;
            nof1=nof1*gu;
            c[16].amount=nof1;
            purchase+=nof1;
            ask();
            break;
            }
        case 2:
            {
          c[17].items="Stabler     ";
            int nof2;
            int st=30;
            cout<<"Enter the count:\n";
            cin>>nof2;
            c[17].quantity=nof2;
            nof2=nof2*st;
            c[17].amount=nof2;
            purchase+=nof2;
            ask();
            break;
            }
        case 3:
            {
          c[18].items="Tape        ";
            int nof3;
            int tp=20;
            cout<<"Enter the count:\n";
            cin>>nof3;
            c[18].quantity=nof3;
            nof3=nof3*tp;
            c[18].amount=nof3;
            purchase+=nof3;
            ask();
            break;
            }
        }
      break;
     }
  }
      }

int cosmetics(){
    int op;
   cout<<"1.Perfumes\n2.Powders\n3.Shampoos\n";
   cin>>op;
    switch(op)
    {
    case 1:
        {
        int op1;
        cout<<"\t\t\tPERFUMES:\nChoose it\n1.FOGG-80\n2.AXE-90\n3.Park Avenue-120\n";
        cin>>op1;
        switch(op1)
        {
        case 1:
            {
          c[19].items="FOGG        ";
            int n1;
            int f=80;
            cout<<"Enter the count:\n";
            cin>>n1;
            c[19].quantity=n1;
            n1=n1*f;
            c[19].amount=n1;
            purchase+=n1;
            ask();
            break;
            }
        case 2:
            {
          c[20].items="AXE         ";
            int n2;
            int a=90;
            cout<<"Enter the count:\n";
            cin>>n2;
            c[20].quantity=n2;
            n2=n2*a;
            c[20].amount=n2;
            purchase+=n2;
            ask();
            break;
            }
        case 3:
            {
          c[21].items="Park Avenue ";
            int n3;
            int pa=120;
            cout<<"Enter the count:\n";
            cin>>n3;
            c[21].quantity=n3;
            n3=n3*pa;
            c[21].amount=n3;
            purchase+=n3;
            ask();
            break;
            }
        }
        break;
    }
        case 2:
            {
        int op2;
        cout<<"\t\t\tPOWDERS:\nChoose it\n1.Gokul Sandal-80\n2.Ponds-30\n3.Z Talc-100\n";
        cin>>op2;
        switch(op2)
        {
        case 1:
            {
          c[22].items="Gokul Sandal ";
            int no1;
            int gs=80;
            cout<<"Enter the count:\n";
            cin>>no1;
            c[22].quantity=no1;
            no1=no1*gs;
            c[22].amount=no1;
            purchase+=no1;
            ask();
            break;
            }
        case 2:
            {
          c[23].items="Ponds       ";
            int no2;
            int po=30;
            cout<<"Enter the count:\n";
            cin>>no2;
            c[23].quantity=no2;
            no2=no2*po;
            c[23].amount=no2;
            purchase+=no2;
            ask();
            break;
            }
        case 3:
            {
          c[24].items="Z Talc      ";
            int no3;
            int z=100;
            cout<<"Enter the count:\n";
            cin>>no3;
            c[24].quantity=no3;
            no3=no3*z;
            c[24].amount=no3;
            purchase+=no3;
            ask();
            break;
            }
        }
      break;
     }
        case 3:
            {
        int op3;
        cout<<"\t\t\tSHAMPOOS:\nChoose it\n1.ClinicPlus-20\n2.Head & Shoulder-30\n3.All Clear-15\n";
        cin>>op3;
        switch(op3)
        {
        case 1:
            {
          c[25].items="ClinicPlus  ";
            int nof1;
            int cp=20;
            cout<<"Enter the count:\n";
            cin>>nof1;
            c[25].quantity=nof1;
            nof1=nof1*cp;
            c[25].amount=nof1;
            purchase+=nof1;
            ask();
            break;
            }
        case 2:
            {
          c[26].items="Head&Shoulder";
            int nof2;
            int hs=30;
            cout<<"Enter the count:\n";
            cin>>nof2;
            c[26].quantity=nof2;
            nof2=nof2*hs;
            c[26].amount=nof2;
            purchase+=nof2;
            ask();
            break;
            }
        case 3:
            {
          c[27].items="AllClear    ";
            int nof3;
            int ac=15;
            cout<<"Enter the count:\n";
            cin>>nof3;
            c[27].quantity=nof3;
            nof3=nof3*ac;
            c[27].amount=nof3;
            purchase+=nof3;
            ask();
            break;
            }
        }
      break;
     }
  }
}

int groceries(){
     int op;
   cout<<"1.Dairy Products\n2.Vegetables\n3.Meat\n";
   cin>>op;
    switch(op)
    {
    case 1:
        {
        int op1;
        cout<<"\t\t\tDAIRY PRODUCTS:\nChoose it\n1.Butter-40\n2.Milk(500ml)-30\n3.Egg(1)-5\n";
        cin>>op1;
        switch(op1)
        {
        case 1:
            {
          c[28].items="Butter      ";
            int n1;
            int bu=40;
            cout<<"Enter the count:\n";
            cin>>n1;
            c[28].quantity=n1;
            n1=n1*bu;
            c[28].amount=n1;
            purchase+=n1;
            ask();
            break;
            }
        case 2:
            {
          c[29].items="Milk(500ml) ";
            int n2;
            int mi=30;
            cout<<"Enter the count:\n";
            cin>>n2;
            c[29].quantity=n2;
            n2=n2*mi;
            c[29].amount=n2;
            purchase+=n2;
            ask();
            break;
            }
        case 3:
            {
          c[30].items="Egg         ";
            int n3;
            int egg=5;
            cout<<"Enter the count:\n";
            cin>>n3;
            c[30].quantity=n3;
            n3=n3*egg;
            c[30].amount=n3;
            purchase+=n3;
            ask();
            break;
            }
        }
        break;
    }
        case 2:
            {
        int op2;
        cout<<"\t\t\tVEGETABLES:\nChoose it\n1.Tomato(1kg)-40\n2.Potato(1kg)-40\n3.Cabbage(1kg)-40\n";
        cin>>op2;
        switch(op2)
        {
        case 1:
            {
          c[31].items="Tomato      ";
            int no1;
            int to=40;
            cout<<"Enter the count:\n";
            cin>>no1;
            c[31].quantity=no1;
            no1=no1*to;
            c[31].amount=no1;
            purchase+=no1;
            ask();
            break;
            }
        case 2:
            {
          c[32].items="Potato      ";
            int no2;
            int pot=40;
            cout<<"Enter the count:\n";
            cin>>no2;
            c[32].quantity=no2;
            no2=no2*pot;
            c[32].amount=no2;
            purchase+=no2;
            ask();
            break;
            }
        case 3:
            {
          c[33].items="Cabbage     ";
            int no3;
            int ca=40;
            cout<<"Enter the count:\n";
            cin>>no3;
            c[33].quantity=no3;
            no3=no3*ca;
            c[33].amount=no3;
            purchase+=no3;
            ask();
            break;
            }
        }
      break;
     }
        case 3:
            {
        int op3;
        cout<<"\t\t\tMEAT:\nChoose it\n1.Goat(1kg)-400\n2.Chicken(1kg)-350\n3.Fish(1kg)-150\n";
        cin>>op3;
        switch(op3)
        {
        case 1:
            {
          c[34].items="Goat        ";
            int nof1;
            int go=400;
            cout<<"Enter the count:\n";
            cin>>nof1;
            c[34].quantity=nof1;
            nof1=nof1*go;
            c[34].amount=nof1;
            purchase+=nof1;
            ask();
            break;
            }
        case 2:
            {
          c[35].items="Chicken     ";
            int nof2;
            int ch=350;
            cout<<"Enter the count:\n";
            cin>>nof2;
            c[35].quantity=nof2;
            nof2=nof2*ch;
            c[35].amount=nof2;
            purchase+=nof2;
            ask();
            break;
            }
        case 3:
            {
          c[36].items="Fish        ";
            int nof3;
            int fi=150;
            cout<<"Enter the count:\n";
            cin>>nof3;
            c[36].quantity=nof3;
            nof3=nof3*fi;
            c[36].amount=nof3;
            purchase+=nof3;
            ask();
            break;
            }
        }
      break;
     }
  }
}

int others(){
       int op;
   cout<<"1.IceCream\n2.Beverages\n3.Rice\n";
   cin>>op;
    switch(op)
    {
    case 1:
        {
        int op1;
        cout<<"\t\t\tICECREAMS:\nChoose it\n1.Cup Ice-10\n2.Cone Ice-40\n3.Stick Ice-25\n";
        cin>>op1;
        switch(op1)
        {
        case 1:
            {
          c[37].items="Cup Ice     ";
            int n1;
            int cui=10;
            cout<<"Enter the count:\n";
            cin>>n1;
            c[37].quantity=n1;
            n1=n1*cui;
            c[37].amount=n1;
            purchase+=n1;
            ask();
            break;
            }
        case 2:
            {
          c[38].items="Cone Ice    ";
            int n2;
            int coi=40;
            cout<<"Enter the count:\n";
            cin>>n2;
            c[38].quantity=n2;
            n2=n2*coi;
            c[38].amount=n2;
            purchase+=n2;
            ask();
            break;
            }
        case 3:
            {
          c[39].items="Stick Ice   ";
            int n3;
            int sti=25;
            cout<<"Enter the count:\n";
            cin>>n3;
            c[39].quantity=n3;
            n3=n3*sti;
            c[39].amount=n3;
            purchase+=n3;
            ask();
            break;
            }
        }
        break;
        }
        case 2:
            {
        int op2;
        cout<<"\t\t\tBEVERAGES:\nChoose it\n1.Miranda(500ml)-40\n2.Sprite(500ml)-35\n3.Slice(1litre)-80\n";
        cin>>op2;
        switch(op2)
        {
        case 1:
            {
          c[40].items="Miranda     ";
            int no1;
            int mir=40;
            cout<<"Enter the count:\n";
            cin>>no1;
            c[40].quantity=no1;
            no1=no1*mir;
            c[40].amount=no1;
            purchase+=no1;
            ask();
            break;
            }
        case 2:
            {
          c[41].items="Sprite      ";
            int no2;
            int spr=35;
            cout<<"Enter the count:\n";
            cin>>no2;
            c[41].quantity=no2;
            no2=no2*spr;
            c[41].amount=no2;
            purchase+=no2;
            ask();
            break;
            }
        case 3:
            {
          c[42].items="Slice       ";
            int no3;
            int sli=80;
            cout<<"Enter the count:\n";
            cin>>no3;
            c[42].quantity=no3;
            no3=no3*sli;
            c[42].amount=no3;
            purchase+=no3;
            ask();
            break;
            }
        }
      break;
     }
        case 3:
            {
        int op3;
        cout<<"\t\t\tRICE:\nChoose it\n1.Basmati Rice(1kg)-240\n2.Siraga Samba Rice(1kg)-230\n3.Brown Rice(1kg)-70\n";
        cin>>op3;
        switch(op3)
        {
        case 1:
            {
          c[43].items="Basmati Rice";
            int nof1;
            int bar=240;
            cout<<"Enter the count:\n";
            cin>>nof1;
            c[43].quantity=nof1;
            nof1=nof1*bar;
            c[43].amount=nof1;
            purchase+=nof1;
            ask();
            break;
            }
        case 2:
            {
          c[44].items="Siraga Samba";
            int nof2;
            int ssr=230;
            cout<<"Enter the count:\n";
            cin>>nof2;
            c[44].quantity=nof2;
            nof2=nof2*ssr;
            c[44].amount=nof2;
            purchase+=nof2;
            ask();
            break;
            }
        case 3:
            {
          c[45].items="Brown Rice  ";
            int nof3;
            int br=70;
            cout<<"Enter the count:\n";
            cin>>nof3;
            c[45].quantity=nof3;
            nof3=nof3*br;
            c[45].amount=nof3;
            purchase+=nof3;
            ask();
            break;
            }
        }
      break;
     }
  }
}

void ask(){
    int op;
    cout<<"Do you want to continue?\n1.Yes\n2.No\n";
    cin>>op;
    switch(op)
    {
    case 1:
        display();
        break;

    case 2:
        cout<<"\n\n\n";
        break;
    }
}

void display(){
    int op;
    cout<<"\n\t\t\tMy Divisions are..:\n\n";
    cout<<"\t\t\t\t1.Snacks\n\t\t\t\t2.Stationery\n\t\t\t\t3.Cosmetics\n\t\t\t\t4.Groceries\n\t\t\t\t5.Others\n";
    cout<<"Select your option:\n";
    cin>>op;
    switch(op)
    {
    case 1:
        snacks();
        break;
    case 2:
        stationery();
        break;
    case 3:
        cosmetics();
        break;
    case 4:
        groceries();
        break;
    case 5:
        others();
        break;
    }
}

int main(){
    cout<<"\t\tWelcome to our Department Store"<<endl;
    display();
    cout<<"  ITEMS\t\t\tQUANTITY\t\tAMOUNT\n";
    for(int i=1;i<=45;i++){
        cout<<c[i].items<<"\t\t   ";
        cout<<c[i].quantity<<"\t\t\t   ";
        cout<<c[i].amount<<"\n";
    }

    cout<<"\n\t\tTotal Purchasing amount: Rs."<<purchase<<endl;
    cout<<"\n\t   ****************ThankingYou!!****************\n";
}
